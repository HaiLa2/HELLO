package com.ntlg;

/**
 *
 *@description:
 *@auther liuyuanmin
 *@date 2020年12月24日
*/
public class Demo {
	
	public static void main(String[] args) {
		new Demo().GuiGuThink(8001);
	}
	
	/**
	 * y = ax²+bx+c
	 * @param a 
	 * @param b
	 * @param c
	 * @param y
	 * @return
	 */
	public void OneAndTwoCalculate(int a, int b, int c, int y){
		float x1 = 0;
		float x2 = 0;
		int der = (b*b) - (4*a*c);
		if(der > 0){
			x1 = (float) ((-b + Math.sqrt(der))/(2*a));
			x2 = (float) ((-b - Math.sqrt(der))/(2*a));
			System.out.println(x1);
			System.out.println(x2);
		}
		else if(der == 0){
			x1 = (-b)/(2*a);
			System.out.println(x1);
		}else{
			System.out.println("x不存在");
		}	
	}
	
	
	/**
	 * 验证“鬼谷猜想”：对任意自然数，若是奇数，就对它乘以 3 再加 1；若是偶数，就对它除以 2，
	 * 这样得到一个新数，再按上述计算规则进行计算，一直进行下去，最终必然得到 1.    
	 * @param n
	 */
	public void GuiGuThink(int n){
		if(n >= 0){
			while(n != 1){
				if(n%2 == 0){
					n /= 2;
				}else{
					n = n*3+1;
				}
			}
			System.out.println("鬼谷猜想成立");
		}else{
			System.out.println("输入的是非自然数");
		}
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
