package com.ntlg;

/**
 *
 *@description:
 *@auther liuyuanmin
 *@date 2020年12月6日
*/
public class Sort {
	
	public static void main(String[] args) {
		int a[] = new int[]{8,9,2,5,7};
		new Sort().selectSort(a);
		for(int i = 0; i < a.length; i++){
			System.out.println(a[i]);
		}
	}
	
	/**
	 * 直接插入排序
	 * @param a 需要排序的数组
	 */
	public void insertSort(int a[]){
		int length = a.length;
		int insertNum;
		for(int i = 0; i < length; i++){
			int j = i - 1;
			insertNum = a[i];
			while(j >= 0 && a[j] > insertNum){
				a[j+1] = a[j];
				j--;
			}
			a[j+1] = insertNum;
		}
	}
	
	/**
	 * 希尔排序
	 * @param a 需要排序的数组
	 */
	public void sheelSort(int[] a){
		int d = a.length;
		while(d != 0){
			d = d/2;
			for(int x = 0; x < d; x++){
				for(int i = x+d; i < a.length; i += d){
					int j = i-d;
					int temp = a[i];
					for(; j >= 0 && temp < a[j]; j -= d){
						a[j+d] = a[j];
					}
					a[j+d] = temp;
				}
			}
		}
	}
	
	/**
	 * 简单选择排序
	 * @param a 需要排序的数组
	 */
	public void selectSort(int[] a){
		int length = a.length;
		for(int i = 0; i < length; i++){
			int temp = a[i];
			int position = i;
			for(int j = i; j < length; j++){
				if(a[j] < temp){
					temp = a[j];
					position = j;
				}
			}
			a[position] = a[i];
			a[i] = temp;
		}
	}
	
	/**
	 * 冒泡排序
	 * @param a 需要排序的数组
	 */
	public void bubbleSort(int[] a){
		int length = a.length;
		int temp;
		for(int i = 0; i < length; i++){
			for(int j = 0; j < length-i; j++){
				if(a[j] > a[j+1]){
					temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;
				}
			}
		}
	}
	
	
	
}
